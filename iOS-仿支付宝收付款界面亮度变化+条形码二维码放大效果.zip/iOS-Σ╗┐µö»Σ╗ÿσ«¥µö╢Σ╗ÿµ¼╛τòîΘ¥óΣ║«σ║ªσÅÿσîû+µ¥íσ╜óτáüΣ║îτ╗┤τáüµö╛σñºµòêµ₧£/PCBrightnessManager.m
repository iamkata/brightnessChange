//
//  PCBrightnessManager.m
//  PCMobileFrontSystem
//
//  Created by zjnx1111 on 2022/3/15.
//  Copyright © 2022 P&C Information. All rights reserved.
//

#import "PCBrightnessManager.h"

//用来保存唯一的单例对象,保证这个全局变量只能当前文件可以访问,不能被extern引用
static PCBrightnessManager *instance = nil;
static dispatch_once_t onceToken;

@interface PCBrightnessManager ()

@property (nonatomic, strong) NSArray <NSString *>*vcArr;
@property (nonatomic, assign) CGFloat lastBrightness;
@property (nonatomic, strong) NSOperationQueue *brightnessQueue;

@end

@implementation PCBrightnessManager

#pragma mark - 初始化

//创建用户单例
+ (instancetype)sharedManager {
    dispatch_once(&onceToken, ^{
        instance = [[PCBrightnessManager alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.vcArr = [NSMutableArray array];
    }
    return self;
}

- (void)clearInstance {
    instance = nil;
    onceToken = 0;
}

- (void)addBrightnessControlWithArr:(NSArray <NSString *>*)vcArr {
    
    self.vcArr = vcArr;
    //保存亮度
    [self saveBrightness];
    //获取nav
    AppDelegate *dele = (AppDelegate *)[UIApplication sharedApplication].delegate;
    UINavigationController *nav = (UINavigationController *)dele.window.rootViewController;
    if (![nav isKindOfClass:[UINavigationController class]]) { return; }
    //设置代理
    nav.delegate = self;
}

#pragma mark - UINavigationControllerDelegate

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    BOOL shouldChange = NO;
    
    NSString *showVC = NSStringFromClass([viewController class]);
    if ([self.vcArr containsObject:showVC]) {
        shouldChange = YES;
    }
    
    if (shouldChange) {
        [self brightnessHigh];
        //添加通知之前先移除通知
        [self removeAllNotification];
        [self addNotification];
    } else {
        [self brightnessNormal];
        //判断是否需要清空单例和通知
        [self judgePushOrPop];
    }
}

//判断是否需要清空单例
- (void)judgePushOrPop {
    //判断是在需要亮的界面的前面还是后面
    AppDelegate *dele = (AppDelegate *)[UIApplication sharedApplication].delegate;
    UINavigationController *nav = (UINavigationController *)dele.window.rootViewController;
    if (![nav isKindOfClass:[UINavigationController class]]) { return; }
    
    NSArray *vcs = nav.viewControllers; //栈数组
    NSMutableArray *strVCS = [NSMutableArray array]; //栈字符串数组
    for (UIViewController *vc in vcs) {
        NSString *vcStr = NSStringFromClass([vc class]);
        [strVCS addObject:vcStr];
    }
    
    //默认清空单例
    BOOL clearInstance = YES;
    for (NSString *vc in self.vcArr) {
        //栈字符串数组里面没有高亮的界面,说明是pop,那就应该清空单例
        if ([strVCS containsObject:vc]) {
            clearInstance = NO;
            break;
        }
    }
    
    //清空单例 是pop的界面
    if (clearInstance) {
        [self clearInstance];
        [self removeAllNotification];
    } else { //是push的界面
        [self removeActiveNotification];
    }
}

#pragma mark - 亮度调解相关

- (void)saveBrightness {
    self.lastBrightness = [UIScreen mainScreen].brightness;
    //NSLog(@"保存的亮度为%f",self.lastBrightness);
}

- (void)brightnessHigh {
    CGFloat currentBrightness = [UIScreen mainScreen].brightness;
    if (currentBrightness >= 0.8) { return; }
    [self graduallySetBrightness:0.8];
}

- (void)brightnessNormal {
    [self graduallyResumeBrightness];
}

//缓慢调解亮度
- (void)graduallySetBrightness:(CGFloat)value {
    if (!_brightnessQueue) {
        _brightnessQueue = [[NSOperationQueue alloc] init];
        //最大操作数1
        _brightnessQueue.maxConcurrentOperationCount = 1;
    }
    //先取消旧的操作
    [_brightnessQueue cancelAllOperations];
    
    //当前亮度
    CGFloat currentBrightness = [UIScreen mainScreen].brightness;
    if (currentBrightness == value) { return; }

    //总时间
    CGFloat totalTime = 0.4;
    CGFloat totalStep = 50;
    CGFloat stepTime = totalTime/totalStep;
    CGFloat stepValue = (value - currentBrightness) / totalStep;
    
    for (CGFloat i = 0; i < totalStep; i++) {
        [_brightnessQueue addOperationWithBlock:^{
            //线程睡眠
            [NSThread sleepForTimeInterval:stepTime];
            [self settingBrightnessWithBrightness:currentBrightness + i * stepValue];
            if (i == totalStep - 1) { //最后一次循环
                if (value > currentBrightness) { //↑
                    [self settingBrightnessWithBrightness:value];
                } else { //↓
                    [self settingBrightnessWithBrightness:_lastBrightness];
                }
            }
        }];
    }
}

//缓慢恢复亮度
- (void)graduallyResumeBrightness{
    [self graduallySetBrightness:_lastBrightness];
}

- (void)settingBrightnessWithBrightness:(CGFloat)brightness {
    if (UIDevice.currentDevice.systemVersion.floatValue < 13.0) {
        [UIScreen mainScreen].brightness = brightness;
    } else {
        //iOS13需要在主线程修改,否则崩溃
        dispatch_async(dispatch_get_main_queue(), ^{
            [UIScreen mainScreen].brightness = brightness;
        });
    }
}

#pragma mark - 通知相关

- (void)addNotification {
    //监听app进入后台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willResignActive) name:UIApplicationWillResignActiveNotification object:nil];
    //监听app进入前台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didBecomeActive) name:UIApplicationDidBecomeActiveNotification object:nil];
    //无论是代码调解亮度,系统调解亮度,还是用户调解亮度,这个通知都会调用,所以无法区分是不是用户自己调解的
    //用户亮度调节通知,app在前台才能检测到通知,app进入后台后无法检测亮度变化通知
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(brightnessDidChange) name:UIScreenBrightnessDidChangeNotification object:nil];
}

- (void)removeActiveNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillResignActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)removeAllNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillResignActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:UIScreenBrightnessDidChangeNotification object:nil];
}

- (void)willResignActive {
    [self brightnessNormal];
}

-(void)didBecomeActive {
    //如果用户后台调解了亮度,进入前台后再保存初始亮度
    CGFloat currentBrightness = [UIScreen mainScreen].brightness;
    if (currentBrightness != self.lastBrightness) {
        [self saveBrightness];
    }
    [self brightnessHigh];
}

- (void)brightnessDidChange {
    //NSLog(@"监听到亮度改变,%f",[UIScreen mainScreen].brightness);
    [self saveBrightness];
}

@end
