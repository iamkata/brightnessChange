//
//  PCBarCodeQRCodeManager.m
//  PCMobileFrontSystem
//
//  Created by zjnx1111 on 2022/3/8.
//  Copyright © 2022 P&C Information. All rights reserved.
//

#import "PCBarCodeQRCodeManager.h"
#import "UIView+Gradient.h"

//当前界面类型
typedef enum : NSUInteger {
    //条形码
    BarCodeViewType = 0,
    //二维码界面
    QRCodeViewType
} BarCodeQRCodeViewType;

@interface PCBarCodeQRCodeManager ()

@property (nonatomic, strong) UIView *backView; //背景视图

@property (nonatomic, strong) UIView *tipContentView; //提示总view
@property (nonatomic, strong) UILabel *tipLabel; //提示label
@property (nonatomic, strong) UIButton *okBtn;    //确定按钮

@property (nonatomic, assign) UIStatusBarStyle oldStatusBarStyle;
@property (nonatomic, assign) CGRect oldFrame; //图片的初始位置
@property (nonatomic, strong) UIView *barView; //条形码父视图
@property (nonatomic, strong) UILabel *barTipLabel; //条形码数字右边的提醒标签
@property (nonatomic, strong) UILabel *barLabel; //条形码数字
@property (nonatomic, strong) UIImageView *barImageV; //条形码图片
@property (nonatomic, strong) UIImageView *QRCodeImageV; //二维码图片

@property (nonatomic, assign) BOOL shouldHideLoading; //是否应该隐藏loading
@property (nonatomic, assign) BarCodeQRCodeViewType viewType; //当前界面类型
@property (nonatomic, copy) RemovedBlock removedBlock;
 
@end

@implementation PCBarCodeQRCodeManager

#pragma mark - 初始化

//用来保存唯一的单例对象,保证这个全局变量只能当前文件可以访问,不能被extern引用
static id instance;

//创建用户单例
+ (instancetype)sharedManager {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[PCBarCodeQRCodeManager alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.oldFrame = CGRectZero;
    }
    return self;
}

#pragma mark - 条形码相关

//横屏显示条形码
- (void)showBarCodeImageFullScreenWithBarCodeView:(UIView *)barCodeView fullBarString:(NSString *)fullBarString removedBlock:(RemovedBlock)removedBlock {
    //当前界面类型
    self.viewType = BarCodeViewType;
    
    self.removedBlock = removedBlock;
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    self.backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    self.backView.backgroundColor = [UIColor whiteColor];
    self.backView.alpha = 0;
    [window addSubview:self.backView];
    
    //坐标转换
    self.oldFrame = [barCodeView convertRect:barCodeView.bounds toView:window];
    //假数据
    //self.oldFrame = CGRectMake(16, 100, kScreenWidth - 32, 60);
    
    NSString *tipStr = @"该条形码数字用于收银员当面交易，泄露给他人可直接从你的账户中扣款。【谨防诈骗】";
    
    self.tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.oldFrame.origin.x, self.oldFrame.origin.y, self.oldFrame.size.width, 60)];
    self.tipLabel.text = tipStr;
    self.tipLabel.textColor = [UIColor colorFormString:@"#222222"];
    self.tipLabel.font = [PCUtil fontWithName:@"PingFangSC-Regular" size:18.0f];
    self.tipLabel.textAlignment = NSTextAlignmentCenter;
    self.tipLabel.numberOfLines = 0;
    
    self.okBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.okBtn.frame = CGRectMake(self.oldFrame.origin.x, self.tipLabel.mh_bottom + 20, self.oldFrame.size.width, 40);
    [self.okBtn setTitle:@"确认" forState:UIControlStateNormal];
    [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.okBtn.layer.cornerRadius = 7;
    self.okBtn.layer.masksToBounds = YES;
    [self.okBtn setGradientBackgroundWithColors:@[[UIColor colorWithHex:0xCCA67C],[UIColor colorWithHex:0xB38959]] locations:nil startPoint:CGPointMake(0, 0) endPoint:CGPointMake(1, 1)];
    [self.okBtn addTarget:self action:@selector(okBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    //条形码数字右边的提醒标签 业务让去掉了
//    self.barTipLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.oldFrame.origin.x, self.oldFrame.origin.y, self.oldFrame.size.width, 60)];
//    self.barTipLabel.backgroundColor = [UIColor colorFormString:@"#F8F3EF"];
//    self.barTipLabel.text = tipStr;
//    self.barTipLabel.textColor = [UIColor colorFormString:@"#AF8158"];
//    self.barTipLabel.font = [PCUtil fontWithName:@"PingFangSC-Regular" size:15.0f];
//    self.barTipLabel.textAlignment = NSTextAlignmentCenter;
//    self.barTipLabel.hidden = YES;
    
    for (UIView *view in barCodeView.subviews) {
        if ([view isKindOfClass:[UILabel class]]) { //条形码数字
            //UILabel *label = (UILabel *)view;
            self.barLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.oldFrame.origin.x, self.oldFrame.origin.y, self.oldFrame.size.width, 60)];
            //self.barLabel.text = label.text;
            self.barLabel.text = fullBarString;
            self.barLabel.textColor = [UIColor colorFormString:@"#222222"];
            self.barLabel.font = [PCUtil fontWithName:@"PingFangSC-Regular" size:18.0f];
            self.barLabel.textAlignment = NSTextAlignmentCenter;
            self.barLabel.hidden = YES;
        }
        if ([view isKindOfClass:[UIImageView class]]) { //条形码图片
            UIImageView *imageV = (UIImageView *)view;
            self.barImageV = [[UIImageView alloc] initWithFrame:CGRectMake(self.oldFrame.origin.x, self.tipLabel.mh_bottom + 20, self.oldFrame.size.width, 40)];
            self.barImageV.image = imageV.image;
            self.barImageV.userInteractionEnabled = YES;
            self.barImageV.hidden = YES;
        }
    }
    
    [self.backView addSubview:self.tipLabel];
    [self.backView addSubview:self.okBtn];
    [self.backView addSubview:self.barTipLabel];
    [self.backView addSubview:self.barLabel];
    [self.backView addSubview:self.barImageV];

    [UIView animateWithDuration:0.4 animations:^{
        self.okBtn.transform = CGAffineTransformMakeRotation(M_PI * 0.5);
        self.okBtn.mh_left = kScaleWidth(100);
        self.okBtn.mh_height = kScaleWidth(345);
        self.okBtn.mh_width = kScaleWidth(44);
        self.okBtn.mh_centerY = self.backView.mh_centerY;
        
        self.tipLabel.transform = CGAffineTransformMakeRotation(M_PI * 0.5);
        self.tipLabel.mh_left = kScreenWidth - kScaleWidth(140 + 60);
        self.tipLabel.mh_height = kScaleWidth(462);
        self.tipLabel.mh_width = kScaleWidth(60);
        self.tipLabel.mh_centerY = self.backView.mh_centerY;
        
        self.barTipLabel.transform = CGAffineTransformMakeRotation(M_PI * 0.5);
        self.barTipLabel.mh_left = kScreenWidth - kScaleWidth(30 + 44);
        self.barTipLabel.mh_height = kScreenHeight;
        self.barTipLabel.mh_width = kScaleWidth(44);
        self.barTipLabel.mh_centerY = self.backView.mh_centerY;
        
        self.barImageV.transform = CGAffineTransformMakeRotation(M_PI * 0.5);
        self.barImageV.mh_left = kScaleWidth(90);
        self.barImageV.mh_height = kScreenHeight - ((YZ_StatusBarHeight + kScaleWidth(20)) * 2);
        self.barImageV.mh_width = kScaleWidth(134);
        self.barImageV.mh_centerY = self.backView.mh_centerY;
        
        self.barLabel.transform = CGAffineTransformMakeRotation(M_PI * 0.5);
        self.barLabel.mh_left = kScreenWidth - kScaleWidth(90 + 52);
        self.barLabel.font = [PCUtil fontWithName:@"PingFangSC-Regular" size:37.0f];
        self.barLabel.mh_height = kScreenHeight - ((YZ_StatusBarHeight + kScaleWidth(20)) * 2);
        self.barLabel.mh_width = kScaleWidth(52);
        self.barLabel.mh_centerY = self.backView.mh_centerY;
        
        self.backView.alpha = 1;
    } completion:^(BOOL finished) {
        //有蒙版的时候不显示loading
        self.shouldHideLoading = YES;
    }];
}

//更新条形码
- (void)updateBarCodeImageWithTex:(NSString *)text image:(UIImage *)image {
    if (!text || !image) {
        [self hideBackView]; return;
    }
    self.barLabel.text = text;
    self.barImageV.image = image;
}

#pragma mark - 二维码码相关

//全屏显示二维码
- (void)showQRCodeImageFullScreenWithImageV:(UIImageView *)imageV removedBlock:(RemovedBlock)removedBlock {
    //当前界面类型
    self.viewType = QRCodeViewType;
    
    self.removedBlock = removedBlock;
    UIImage *image = imageV.image;
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    
    self.backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    self.backView.backgroundColor = [UIColor whiteColor];
    self.backView.alpha = 0;
    
    //坐标转换
    self.oldFrame = [imageV convertRect:imageV.bounds toView:window];
    self.QRCodeImageV = [[UIImageView alloc] initWithFrame:self.oldFrame];
    self.QRCodeImageV.tag = 567;
    self.QRCodeImageV.image = image;
    
    [self.backView addSubview:self.QRCodeImageV];
    [window addSubview:self.backView];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideBackView)];
    [self.backView addGestureRecognizer:tap];
    
    [UIView animateWithDuration:0.4 animations:^{
        self.QRCodeImageV.mh_width = kScaleWidth(220);
        self.QRCodeImageV.mh_height = kScaleWidth(220);
        self.QRCodeImageV.center = self.backView.center;
        self.backView.alpha = 1;
    } completion:nil];
}

//更新二维码
- (void)updateQRCodeImage:(UIImage *)image {
    if (!image) {
        [self hideBackView]; return;
    }
    self.QRCodeImageV.image = image;
}

#pragma mark - 其他方法

- (void)okBtnClicked {
    [self.tipLabel removeFromSuperview];
    [self.okBtn removeFromSuperview];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideBackView)];
    [self.backView addGestureRecognizer:tap];
    
    [self showBarCodeView];
}

- (void)showBarCodeView {
    self.barTipLabel.hidden = NO;
    self.barLabel.hidden = NO;
    self.barImageV.hidden = NO;
    
    //没有蒙版的时候显示loading
    self.shouldHideLoading = NO;
}

//移除放大的界面
- (void)hideBackView {
    //不带动画
    [self.backView removeFromSuperview];
    if (self.removedBlock) {
        self.removedBlock();
    }
}

- (void)showLoading {
    if (!self.backView) {
        return;
    }
    if (self.shouldHideLoading) {
        return;
    }
    
    if (self.viewType == BarCodeViewType) {
        [self.backView showLandscapeWaitingView];
    } else if (self.viewType == QRCodeViewType) {
        [self.backView showWaitingView1:@"加载中..."];
    }
}

- (void)hideLoading {
    if (!self.backView) {
        return;
    }
    
    if (self.viewType == BarCodeViewType) {
        [self.backView hideLandscapeWaitingView];
    } else if (self.viewType == QRCodeViewType) {
        [self.backView hideWaitingView];
    }
}

@end
