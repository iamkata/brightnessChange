//
//  PCBarCodeQRCodeManager.h
//  PCMobileFrontSystem
//
//  Created by zjnx1111 on 2022/3/8.
//  Copyright © 2022 P&C Information. All rights reserved.
//
//  条形码、二维码放大单例

#import <Foundation/Foundation.h>

typedef void (^RemovedBlock)(void);

NS_ASSUME_NONNULL_BEGIN

@interface PCBarCodeQRCodeManager : NSObject

+ (instancetype)sharedManager;

//横屏显示条形码
- (void)showBarCodeImageFullScreenWithBarCodeView:(UIView *)barCodeView fullBarString:(NSString *)fullBarString removedBlock:(RemovedBlock)removedBlock;
//更新条形码
- (void)updateBarCodeImageWithTex:(NSString *)text image:(UIImage *)image;

//全屏显示二维码
- (void)showQRCodeImageFullScreenWithImageV:(UIImageView *)imageV removedBlock:(RemovedBlock)removedBlock;
//更新二维码
- (void)updateQRCodeImage:(UIImage *)image;

//移除放大的界面
- (void)hideBackView;

- (void)showLoading;
- (void)hideLoading;

@end

NS_ASSUME_NONNULL_END
