//
//  PCBrightnessManager.h
//  PCMobileFrontSystem
//
//  Created by zjnx1111 on 2022/3/15.
//  Copyright © 2022 P&C Information. All rights reserved.
//
//  亮度调解单例

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCBrightnessManager : NSObject <UINavigationControllerDelegate>

+ (instancetype)sharedManager;

- (void)clearInstance;

//添加亮度调解的类, 参数是类字符串
- (void)addBrightnessControlWithArr:(NSArray <NSString *>*)vcArr;

@end

NS_ASSUME_NONNULL_END
